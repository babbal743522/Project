package com.example.collegeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
 EditText urname, urpassword;
 Button clk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        urname = (EditText) findViewById(R.id.username);
        urpassword = (EditText) findViewById(R.id.password);
        clk = (Button) findViewById(R.id.button3);
    }
    public void movepage(View v)
    {
        String stname = urname.getText().toString();
        String stpassword = urpassword.getText().toString();

        if (stname.equals("babbal23") && stpassword.equals("rejot123")){
            Intent in = new Intent(MainActivity.this,Main2Activity.class);
                         startActivity(in);
        }

       else if( stname.equals("prabh001") && stpassword.equals("bindu34")) {
            Intent in = new Intent(MainActivity.this, Main2Activity.class);
            startActivity(in);
        }
        else if( stname.equals("sndy99") && stpassword.equals("brar71")) {
            Intent in = new Intent(MainActivity.this, Main2Activity.class);
            startActivity(in);
        }
        else if(stname.equals("") && stpassword.equals("")){
            Toast.makeText(getBaseContext(),"Enter both username and password",Toast.LENGTH_SHORT).show();

        }
        else {
            Toast.makeText(getBaseContext(),"Either the username or password is wrong!!",Toast.LENGTH_SHORT).show();

        }
    }
}
